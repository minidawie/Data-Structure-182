package phase2;

public class StackException extends RuntimeException {

public StackException(String s) {
            super(s);
        } // end constructor
    } // end StackException
